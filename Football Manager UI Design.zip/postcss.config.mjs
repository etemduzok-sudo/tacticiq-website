// Placeholder config for Figma Make compatibility
// This React Native project does not use PostCSS

export default {
  plugins: {},
};
